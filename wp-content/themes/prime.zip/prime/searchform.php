<!-- custom search form -->
<div id="searchform">
<form method="get" action="<?php bloginfo('url'); ?>/">
<input type="text" value="search..." onfocus="if (this.value == 'search...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'search...';}" name="s" id="search" />
<input type="submit" id="search-submit" name="submit" value="GO" />
</form>
</div>
