Thank you for downloading my theme.

Explanation post_image()
