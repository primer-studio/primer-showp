=== Kadence Woocommerce Elementor Pro ===
Tags: elementor, woocommerce
Requires at least: 4.4
Requires PHP: 5.4
Tested up to: 5.3.2
Stable tag: 1.1.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Elementor for Woocommerce. This plugin adds archive and checkout templates to create custom archive pages as well as for a custom checkout page.

== Description ==

Elementor for Woocommerce. This plugin adds archive and checkout templates to create custom archive pages as well as for a custom checkout page.

== Changelog ==

= 1.1.6 =
* Add: New Archive Title Widget

= 1.1.5 =
* Add: product sku, tags, category, custom meta to loop options.

= 1.1.4 =
* Fix: Update issue.

= 1.1.3 =
* Fix: API issue

= 1.1.2 =
* Fix: Category Meta input issue.

= 1.1.1 =
* Update: Pot language files.

= 1.1.0 =
* Fix issue with select not showing.
* Update: Mark is woocommerce true.

= 1.0.9 =
* Update: Remove Notice.
* Update: Fix image icon issue.

= 1.0.8 =
* Update: Tweek Loop Template options.
* Update: Templates to remove yoast settings.

= 1.0.7 =
* Update: Virtue archive fix.

= 1.0.6 =
* Update: add product loop template options.

= 1.0.5 =
* Update: add option to assign product templates to a category of products.
 Logic = if product has template set to default check it's assigned categories for an assigned template before using the default from the woocommerce settings.

= 1.0.4 =
* Update: Fix invalid instance ID.

= 1.0.2 =
* Update: API connection.
* Add: Archive description widget.

= 1.0.1 =
* Fix: Issue where notice wasn't showing when activated without the free version.

= 1.0.0 =
* Initial Release.